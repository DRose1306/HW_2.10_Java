package Package;

public class NbaPlayer {
    public String nickName;
    int number;
    private int armSpan;
    private int height;

    public NbaPlayer(){
    }

    public NbaPlayer(String nickName) {
        this.nickName = nickName;
    }
    public NbaPlayer(int number){
        this.number = number;
    }

    public NbaPlayer(String nickName, int number) {

    }

    public int getArmSpan() {
        return armSpan;
    }

    public int getHeight() {
        return height;
    }

    public void setArmSpan(int armSpan) {
        this.armSpan = armSpan;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public static String makeDunk(){
        String s = "Baaanngg, DRose to Big, to Strong, to Fast, to Good";
        return s;
    }
    public NbaPlayer(NbaPlayer original) {
        this(original.nickName, original.number);
    }

}
///1.1 В созданном пакете создайте класс с минимум 3мя полями
//// для одного из объектов реального мира (студент, батарейка, автомобиль...).
//// Одно из полей сделайте публичным, второе – без модификатора доступа,
//// остальные – приватными. Создайте объект этого класса в программе
//// и попробуйте установить значения для полей. Какие поля возможно установить?
//1.3 Напишите минимум 2 конструктора для класса 1.
//1.4 Реализуйте геттеры и сеттеры для приватных полей класса 1.
//1.5 Создайте другие методы для класса (по желанию).
//1.6 Добавьте клонирующий конструктор к классу 1.
