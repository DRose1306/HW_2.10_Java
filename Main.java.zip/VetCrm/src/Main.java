import owner.Owner;
import pet.Animal;
//import VetDoctor;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.Set;

public class Main {
    private static final Scanner SCN = new Scanner(System.in);

    public static void main(String[] args) {
        Animal cat = new Animal();
        System.out.println(cat.getAnimalId());
        Animal dog = new Animal();
        System.out.println(dog.getAnimalId());

        Owner owner = new Owner();
        System.out.println(owner.getCustomerId());
        System.out.println(fillInOwnerData());


        /*Animal animal = fillInAnimalData();

        System.out.println(animal);
        System.out.println();
        System.out.println();*/


        // Doctor
        // 1.1 Name // Имя
        // 1.2 Surname // Имя
        //2. Schedule // График
        //3. Specialization // Специализация
        //4. Work experience // Опыт
        //5. Rating // Рейтинг

        // Customer
        System.out.println(1L); // customerId;
        System.out.println("Василий"); //2.1 Name
        System.out.println("Пупкин"); //2.2 Surname;
        System.out.println(LocalDate.of(1984, 1, 8)); //3. BirthDate;
        System.out.println("г. Берлин, ул. Дункельштрассе, д. 23, кв. 15, 15053"); // Address;
        System.out.println("+15457879999"); // Mob number;
        System.out.println(Set.of(1L)); //Collection of animals' ids

        // Doctor
        System.out.println("Айболит"); // 1.1 Name // Имя
        System.out.println("Пилюлькин");// 1.2 Surname // Имя
        //2. Schedule // График
        System.out.println("Добрый доктор"); //3. Specialization // Специализация
        System.out.println("Пупкин"); // Work experience // Опыт
        System.out.println(4.55);// Rating // Рейтинг


    }

    /**
     * Принимает от пользователя данные о животном
     * @return экземпляр класса Animal
     */
   /* private static Animal fillInAnimalData() {
        Animal animal = new Animal();
        System.out.println("Введите тип животного");
        animal.setAnimalType(SCN.nextLine());
        System.out.println("Введите породу животного");
        animal.setBreed(SCN.nextLine());
        System.out.println("Введите кличку животного");
        animal.setNickname(SCN.nextLine());
        System.out.println("Введите вес животного");
        animal.setWeight(SCN.nextDouble());
        System.out.println("Введите год рождения животного");
        int year = SCN.nextInt();
        System.out.println("Введите числом месяц рождения животного");
        int month = SCN.nextInt();
        System.out.println("Введите числом день рождения животного");
        int day = SCN.nextInt();
        animal.setBirthdate(LocalDate.of(year, month, day));

        return animal;
    } */

    //private long animalId;
    //    private String animalType;
    //    private String breed;
    //    private String nickname;
    //    private double weight;
    //    private LocalDate birthdate;
    //    private String color;
    //    private boolean isIll;
    //    private Gender gender = Gender.UNKNOWN;
    //    private boolean hasVaccinateCertificate;

    private static Owner fillInOwnerData() {
        Owner owner = new Owner();
        //System.out.println("Введите id хозяина");
        //owner.setCustomerId(SCN.nextLong());
        System.out.println("Введите имя хозяина");
        owner.setName(SCN.nextLine());
        System.out.println("Введите фамилию хозяина");
        owner.setSurname(SCN.nextLine());
        System.out.println("Введите дату рождения хозяина");
        owner.setBirthDate(LocalDate.of(1997,6,13));
        System.out.println(owner.getBirthDate());
        System.out.println("Введите адрес хозяина");
        owner.setAddress(SCN.nextLine());
        System.out.println("Введите номер телефон хозяина");
        owner.setMob_number(SCN.nextLine());
        System.out.println("Введите питомцев хозяина");
        owner.setCollectionOfAnimals(SCN.nextLine());
        return owner;
    }
}