package pet;

public enum Gender {
    MALE,
    FEMALE,
    UNKNOWN,
    MIXED
}
