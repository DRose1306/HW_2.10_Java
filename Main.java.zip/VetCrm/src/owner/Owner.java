package owner;

import java.time.LocalDate;

public class Owner {

    public static long id = 0;
    private long customerId = 0;
    private String Name;
    private String Surname;
    private LocalDate BirthDate;
    private String Address;
    private String Mob_number;
    private String CollectionOfAnimals;

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public void setBirthDate(LocalDate birthDate) {
        BirthDate = birthDate;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public void setMob_number(String mob_number) {
        Mob_number = mob_number;
    }

    public void setCollectionOfAnimals(String collectionOfAnimals) {
        CollectionOfAnimals = collectionOfAnimals;
    }

    public Owner(){
        this.customerId = id++;
    }

    public long getCustomerId() {
        return customerId;
    }

    public String getName() {
        return Name;
    }

    public String getSurname() {
        return Surname;
    }

    public LocalDate getBirthDate() {
        return BirthDate;
    }

    public String getAddress() {
        return Address;
    }

    public String getMob_number() {
        return Mob_number;
    }

    public String getCollectionOfAnimals() {
        return CollectionOfAnimals;
    }
}
